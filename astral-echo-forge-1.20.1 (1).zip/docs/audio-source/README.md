# Astral Echo soundtrack source assets

This folder contains the original synthesized, uncompressed stereo WAV masters and the Python generator for the Astral Grove ambience and two original music-disc tracks. Keep these masters for remixing, arrangement changes, or producing future encodes. Runtime copies live in `src/main/resources/assets/astral_echo/sounds/` as OGG Vorbis for Minecraft.

The WAV source files are documentation/editing assets only. Gradle packages `src/main/resources`, so they are not copied into the distributable mod JAR.

Regenerate the masters with Python 3 and NumPy:

```sh
python generate_soundtrack.py
```
