package com.example.astralecho.item;

import com.example.astralecho.AstralEcho;
import com.example.astralecho.sound.AstralSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

public class GroveSigilItem extends Item {
    public static final ResourceKey<Level> ASTRAL_GROVE = ResourceKey.create(Registries.DIMENSION,
            new ResourceLocation(AstralEcho.MOD_ID, "astral_grove"));

    public GroveSigilItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            ServerLevel destination = serverPlayer.server.getLevel(
                    serverPlayer.level().dimension().equals(ASTRAL_GROVE) ? Level.OVERWORLD : ASTRAL_GROVE);
            if (destination == null) {
                player.displayClientMessage(Component.literal("The Astral Grove isn't available in this world."), true);
                return InteractionResultHolder.fail(stack);
            }
            BlockPos target;
            if (destination.dimension() == ASTRAL_GROVE) {
                target = new BlockPos(0, destination.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, 0, 0), 0);
            } else {
                BlockPos spawn = destination.getSharedSpawnPos();
                target = new BlockPos(spawn.getX(), destination.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        spawn.getX(), spawn.getZ()), spawn.getZ());
            }
            serverPlayer.teleportTo(destination, target.getX() + 0.5, target.getY() + 1.0, target.getZ() + 0.5,
                    serverPlayer.getYRot(), serverPlayer.getXRot());
            destination.playSound(null, target, AstralSounds.ASTRAL_BURST.get(), SoundSource.PLAYERS, 1.3F, 0.65F);
            serverPlayer.getCooldowns().addCooldown(this, 60);
            serverPlayer.displayClientMessage(Component.literal(destination.dimension() == ASTRAL_GROVE
                    ? "Welcome to the Astral Grove ✦" : "The stars guide you home."), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
