package com.example.astralecho.client;

import com.example.astralecho.AstralEcho;
import com.example.astralecho.entity.CelestialDevourer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;

public class CelestialDevourerRenderer extends AstralMobRenderer<CelestialDevourer> {
    public CelestialDevourerRenderer(EntityRendererProvider.Context context) {
        super(context, 1.15F, new ResourceLocation(AstralEcho.MOD_ID, "textures/entity/celestial_devourer.png"));
    }

    @Override
    protected void scale(CelestialDevourer entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.45F, 1.55F, 1.45F);
    }
}
