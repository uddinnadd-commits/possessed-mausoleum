package com.example.astralecho.client;

import com.example.astralecho.AstralEcho;
import com.example.astralecho.entity.AstralEntities;
import com.example.astralecho.entity.AstralStalker;
import com.example.astralecho.entity.CelestialDevourer;
import com.example.astralecho.entity.StellarWisp;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AstralEcho.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class AstralClientEvents {
    public static final ModelLayerLocation ASTRAL_MOB_LAYER = new ModelLayerLocation(new ResourceLocation(AstralEcho.MOD_ID, "astral_mob"), "main");

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ASTRAL_MOB_LAYER, AstralMobModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(AstralEntities.ASTRAL_STALKER.get(), context -> new AstralMobRenderer<AstralStalker>(
                context, 0.45F, new ResourceLocation(AstralEcho.MOD_ID, "textures/entity/astral_stalker.png")));
        event.registerEntityRenderer(AstralEntities.STELLAR_WISP.get(), context -> new AstralMobRenderer<StellarWisp>(
                context, 0.3F, new ResourceLocation(AstralEcho.MOD_ID, "textures/entity/stellar_wisp.png")));
        event.registerEntityRenderer(AstralEntities.CELESTIAL_DEVOURER.get(), context -> new CelestialDevourerRenderer(context));
    }
    private AstralClientEvents() {}
}
