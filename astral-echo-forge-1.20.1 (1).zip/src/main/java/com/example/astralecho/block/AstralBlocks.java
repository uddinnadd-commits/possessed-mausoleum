package com.example.astralecho.block;

import com.example.astralecho.AstralEcho;
import com.example.astralecho.item.AstralItems;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class AstralBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, AstralEcho.MOD_ID);
    public static final DeferredRegister<Item> BLOCK_ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AstralEcho.MOD_ID);

    public static final RegistryObject<Block> STARFALL_ORE = BLOCKS.register("starfall_ore",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DIAMOND_ORE).strength(3.5F).requiresCorrectToolForDrops()));
    public static final RegistryObject<Block> ASTRAL_LANTERN = BLOCKS.register("astral_lantern",
            () -> new LanternBlock(BlockBehaviour.Properties.copy(Blocks.LANTERN).lightLevel(state -> 15).strength(3.5F)));
    public static final RegistryObject<Block> ASTRAL_LOG = BLOCKS.register("astral_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.OAK_LOG).strength(2.2F)));
    public static final RegistryObject<Block> ASTRAL_LEAVES = BLOCKS.register("astral_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.copy(Blocks.OAK_LEAVES).strength(0.2F).lightLevel(state -> 2)));
    public static final RegistryObject<Block> ASTRAL_PLANKS = BLOCKS.register("astral_planks",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.OAK_PLANKS).strength(2.0F)));

    public static final RegistryObject<Item> STARFALL_ORE_ITEM = BLOCK_ITEMS.register("starfall_ore",
            () -> new BlockItem(STARFALL_ORE.get(), new Item.Properties()));
    public static final RegistryObject<Item> ASTRAL_LANTERN_ITEM = BLOCK_ITEMS.register("astral_lantern",
            () -> new BlockItem(ASTRAL_LANTERN.get(), new Item.Properties()));
    public static final RegistryObject<Item> ASTRAL_LOG_ITEM = BLOCK_ITEMS.register("astral_log",
            () -> new BlockItem(ASTRAL_LOG.get(), new Item.Properties()));
    public static final RegistryObject<Item> ASTRAL_LEAVES_ITEM = BLOCK_ITEMS.register("astral_leaves",
            () -> new BlockItem(ASTRAL_LEAVES.get(), new Item.Properties()));
    public static final RegistryObject<Item> ASTRAL_PLANKS_ITEM = BLOCK_ITEMS.register("astral_planks",
            () -> new BlockItem(ASTRAL_PLANKS.get(), new Item.Properties()));

    private AstralBlocks() {}
}
